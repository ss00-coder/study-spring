package com.app.dependency.dependency.qualifier;

public interface Computer {
    public int getScreenSize();
}
