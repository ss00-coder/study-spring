package com.app.dependency.dependency;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class Computer {
    private int ram;
}
