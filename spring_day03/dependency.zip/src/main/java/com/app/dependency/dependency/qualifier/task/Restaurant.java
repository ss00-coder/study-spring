package com.app.dependency.dependency.qualifier.task;

import org.springframework.stereotype.Component;

public interface Restaurant {
    public int steak = 50000;
    public boolean isSalad();
}
