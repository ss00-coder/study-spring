package com.example.threetier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreeTierApplicationTests {

    @Test
    void contextLoads() {
    }

}
