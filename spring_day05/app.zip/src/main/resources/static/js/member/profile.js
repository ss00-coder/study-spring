$("div#category .profile").on("click", function () {
    let text = `
        <div class="close-button-wrap">
            <img src="/images/close.png">
        </div>
        <h3 class="title">프로필 변경</h3>
        <h5>원하는 프로필로 변경해주세요.<br>권장 규격은 30 x 30입니다.</h5>
        <label class="profile-wrap">
            <div class="profile">
                <img src="/images/default-profile.png">
            </div>
            <input type="file" name="profile" style="display: none;"> 
        </label>
        <h5 class="warn"></h5>
        <button class="save">저장</button>
    `;
    showWarnModal(text);
});

$("div.modal").on("change", "input[name='profile']",function (e) {
    let reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = function (e) {
        let url = e.target.result;
        if (url.includes('image')) {
            $("label div.profile").find("img").attr('src', url);
            $("h5.warn").text("");
            $("button.save").css("background-color", "rgb(235 124 120)");
            $("button.save").css("cursor", "pointer");
        } else {
            $("label div.profile").find("img").attr('src', "/images/default-profile.png");
            $("h5.warn").text("이미지 파일만 프로필로 설정할 수 있습니다.");
            $("h5.warn").css("color", "red");
            $("button.save").css("background-color", "rgba(235, 124, 120, 0.27)");
        }
    }
});

$("div.modal").on("click", "button.save", function(){
    if($("input[name='profile']").val()) {
        /* 저장 클릭 시 */
    }
});