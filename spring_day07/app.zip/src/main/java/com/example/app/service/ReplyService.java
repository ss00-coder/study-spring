package com.example.app.service;

import com.example.app.domain.vo.ReplyVO;

import java.util.List;

public interface ReplyService {
    //    댓글 목록
    public List<ReplyVO> getList(Long id);

    //    댓글 작성
    public void write(ReplyVO replyVO);

    //    댓글 수정
    public void modify(ReplyVO replyVO);

    //    댓글 삭제
    public void remove(Long id);

    //    게시글의 댓글 전체 삭제
    public void removeAll(Long postId);
}
