package com.example.app.service;

import com.example.app.dao.ReplyDAO;
import com.example.app.domain.vo.ReplyVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReplyServiceImpl implements ReplyService {
    private final ReplyDAO replyDAO;

    @Override
    public List<ReplyVO> getList(Long id) {
        return replyDAO.findAll(id);
    }

    @Override
    public void write(ReplyVO replyVO) {
        replyDAO.save(replyVO);
    }

    @Override
    public void modify(ReplyVO replyVO) {
        replyDAO.setReply(replyVO);
    }

    @Override
    public void remove(Long id) {
        replyDAO.delete(id);
    }

    @Override
    public void removeAll(Long postId) {
        replyDAO.deleteAll(postId);
    }
}
